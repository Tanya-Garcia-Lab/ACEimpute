library(testthat)
library(impeRfect)

test_check("impeRfect")
