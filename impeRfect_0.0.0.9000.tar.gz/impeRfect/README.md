```{r}
# To install the package
devtools::install_github("kylefred/Random-Error-Imputation/impeRfect", ref = "main") 
```
