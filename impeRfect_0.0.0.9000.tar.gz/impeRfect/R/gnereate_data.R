#' Generate longitudinal dataset
#'
#' Generate data set for \code{n} clusters each of size \code{m}
#' with a response Y, 1 binary, time-invariant covariate X1,
#' 1 continuous, time-variant covariate X2, and subject index id
#'
# model formula: Y = X1 + X2 + (1 | id)
# b is random, subject-specific intercept
# epsilon is random error
#' @param n sample size
#' @param m number of visits per subject
#' @param beta 3-dimensional vector of regression coefficients
# beta[1] is intercept
# beta[2] is slope on \code{X1}
# beta[3] is slope on \code{X2}
#' @param sigma standard deviation of teh random error, epsilon
#'
#' @export
generate_data = function(n = 1000, m = 3, beta, sigma = 1) {
  # number of clusters; obs. per cluster; total obs per dataset
  N = n*m
  # random error sd; random errors
  sigma = 1
  epsilon = rnorm(N, 0, sigma)
  # number of random effects
  q = 1
  Z = matrix(1, N)
  # if (q > 1) { Z = cbind(Z, X[, 1:(q - 1)]) }
  # random effects
  b = matrix(rnorm(n*q, 0, 1), n)
  # b = rt(n = n, df = 10)
  # response Y
  sample.data = data.frame(id = rep(1:n, each = m), Y = beta[1] + rep(b, each = m) + epsilon)
  sample.data = sample.data %>%
    mutate(X1 = rep(rbinom(n, 1, 0.5), each = m),
           X2 = rnorm(N, 0, 1),
           Y = Y + beta[2] * X1 + beta[3] * X2)

  return(sample.data)
}
